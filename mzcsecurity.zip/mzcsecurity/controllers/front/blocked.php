<?php
/**
 * MZC Security - Blocked Front Controller
 *
 * Target for the localStorage redirect. Hangs the connection and refreshes
 * the blocking cookie + localStorage so they persist across sessions.
 *
 * @author    Marcin Zbijowski Consulting
 * @copyright 2026 Marcin Zbijowski Consulting
 * @license   MIT
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class MzcsecurityBlockedModuleFrontController extends ModuleFrontController
{
    /** @var bool */
    public $ssl = true;

    /**
     * Allow this controller to respond even when PrestaShop's built-in
     * maintenance mode is active, so the localStorage redirect always works.
     */
    protected function displayMaintenancePage()
    {
        // No-op: blocked endpoint must stay reachable at all times
    }

    /**
     * Hang the connection and refresh both cookie and localStorage.
     * The parent initContent() is intentionally not called.
     */
    public function initContent()
    {
        // Refresh blocking cookie
        setcookie('__mzc_b', '1', [
            'expires'  => time() + 365 * 24 * 3600,
            'path'     => '/',
            'secure'   => (bool) Tools::usingSecureMode(),
            'httponly' => false,
            'samesite' => 'Lax',
        ]);

        // Kill output buffers
        while (ob_get_level()) {
            ob_end_clean();
        }

        // Disable gzip so Content-Length trick works
        if (function_exists('apache_setenv')) {
            @apache_setenv('no-gzip', '1');
        }
        @ini_set('zlib.output_compression', '0');

        header('HTTP/1.1 200 OK');
        header('Content-Type: text/html; charset=utf-8');
        header('Content-Encoding: identity');
        header('Content-Length: 10485760');
        header('X-Accel-Buffering: no');
        header('Cache-Control: no-cache, no-store');

        flush();

        // Refresh localStorage and cookie via JS (belt-and-suspenders)
        echo '<html><head><script>try{'
            . 'localStorage.setItem("__mzc_b","1");'
            . 'document.cookie="__mzc_b=1; path=/; max-age=" + (365*24*3600)'
            . '+ "; SameSite=Lax"'
            . '+ (location.protocol==="https:" ? "; Secure" : "");'
            . '}catch(e){}</script></head><body>';
        flush();

        sleep(86400);
        exit;
    }
}
