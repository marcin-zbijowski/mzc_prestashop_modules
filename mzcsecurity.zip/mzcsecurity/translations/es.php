<?php
global $_MODULE;
$_MODULE = [];

// -------------------------------------------------------------------------
// Source: mzcsecurity.php (main module class)
// -------------------------------------------------------------------------

$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_8a54c91044d95f590aa43df051e5d9dd'] = 'MZC Security';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_34fa656ce0a615e56512ef34db1d5a78'] = 'Bloquee usuarios maliciosos por patrón de correo electrónico, IP y huella del navegador.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_6878f37341771623b644c73b274123bb'] = '¿Está seguro de que desea desinstalar este módulo? La lista de IPs bloqueadas se conservará en la base de datos.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_66dff4bc6149738292b7b2737e7e2e8c'] = 'Token de seguridad inválido.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_a707da41b24c29a1e30d8c04b7863e1f'] = 'La IP ha sido desbloqueada.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_6472dc3fc0227c83e8fab528a472f7fe'] = 'Dirección IP inválida. Por favor, introduzca una dirección IPv4 o IPv6 válida.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_1e813ac1eee5e72279445ed0437e25f9'] = 'La IP %s ha sido bloqueada.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_6e45933da8c7fc3d68abb097ebb22ce8'] = 'Patrones guardados. Se omitieron los siguientes patrones inválidos: ';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_2ffc1ecc5ce2011ab4ae5c648d80394e'] = 'Patrones de correo electrónico guardados correctamente.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_9a7e58ee13cb727cb7c4acc68f4cafe5'] = 'Configuración guardada.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_3271a1764d9263c3636f6867cc516a5b'] = 'Configuración de seguridad';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_d07406f7e7dff881cb2083d0259faf9a'] = 'Activar bloqueo de seguridad';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_fa58d3102986c493a0909538ba47e9c7'] = 'Cuando está activado, los usuarios sospechosos son detectados por patrón de correo y bloqueados por IP y huella del navegador. Las IPs en lista blanca (PS_MAINTENANCE_IP) siempre evitan el bloqueo.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_28797e9f5e55d516b8fa1144adcc7993'] = 'Patrones de bloqueo de correo';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_462e8ca7ff5916f3ff71b6c87f35f9ce'] = 'Un patrón regex por línea. Un usuario cuyo correo coincida con algún patrón tendrá su IP bloqueada inmediatamente. Los patrones no distinguen mayúsculas de minúsculas.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_37a878886cfe6c3389ec4d773ec7936e'] = 'Guardar patrones';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_88e77e80be2b6107a4ad5231d96e499e'] = 'Ejemplos: ^__ bloquea cualquier correo que comience con doble guión bajo. ^__[a-z0-9]+@protonmail\.com$ apunta al patrón de ataque específico. @example\.com$ bloquea el dominio example.com.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_90caa561fee96260a281f9df60a9e5bb'] = 'Bloquear una IP manualmente';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_89e9df324bbf0ee5fe4f4e8db4811268'] = 'Introduzca una dirección IPv4 o IPv6 para bloquear inmediatamente. Esto se suma a la detección automática.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_f7e42f63c4b3962faf68cd4ac158d269'] = 'ej. 192.168.1.100 o 2001:db8::1';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_104505eb540a95706294492b2c54463f'] = 'Bloquear IP';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_e01dbd9600b32f7bd3030e93c4e45caf'] = 'IPs bloqueadas';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_63a6a88c066880c5ac42394a22803ca6'] = 'Actualizar';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_5506fd70d5e3eca59d320eeba70a8356'] = 'No hay IPs bloqueadas actualmente.';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_a12a3079e14ced46e69ba52b8a90b21a'] = 'IP';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Correo';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_fffcb4d1e12c96b2f571f77ad25878b8'] = 'Motivo';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_44749712dbec183e983dcd78a7736c41'] = 'Fecha';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_004bf6c9a40003140292e97330236c53'] = 'Acción';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_193cb08a65f200adaa4f9c35f7e41154'] = 'Desbloquear';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_dd1f775e443ff3b9a89270713580a51b'] = 'Anterior';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Siguiente';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_193cfc9be3b995831c6af2fea6650e60'] = 'Página';
$_MODULE['<{mzcsecurity}prestashop>mzcsecurity_8bf8854bebe108183caeb845c7676ae4'] = 'de';

// -------------------------------------------------------------------------
// Source: views/templates/admin/blocked_table.tpl
// -------------------------------------------------------------------------

$_MODULE['<{mzcsecurity}prestashop>blocked_table_c564022f15424204df340af3a8a6f343'] = '¿Está seguro de que desea desbloquear esta IP?';
