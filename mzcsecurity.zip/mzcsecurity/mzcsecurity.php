<?php
/**
 * MZC Security
 *
 * Block malicious users by email pattern, IP, and browser fingerprint.
 *
 * @author    Marcin Zbijowski Consulting
 * @copyright 2026 Marcin Zbijowski Consulting
 * @license   MIT
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class Mzcsecurity extends Module
{
    public function __construct()
    {
        $this->name = 'mzcsecurity';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Marcin Zbijowski Consulting';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = ['min' => '8.0.0', 'max' => _PS_VERSION_];
        $this->controllers = ['blocked'];

        parent::__construct();

        $this->displayName = $this->l('MZC Security');
        $this->description = $this->l('Block malicious users by email pattern, IP, and browser fingerprint.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall this module? The blocked IP list will be preserved in the database.');
    }

    // -------------------------------------------------------------------------
    // Install / Uninstall
    // -------------------------------------------------------------------------

    public function install()
    {
        return parent::install()
            && $this->registerHook('actionFrontControllerInitAfter')
            && $this->registerHook('actionSubmitAccountBefore')
            && $this->registerHook('actionObjectOrderAddBefore')
            && $this->registerHook('actionAuthentication')
            && $this->registerHook('displayBeforeBodyClosingTag')
            && $this->installDb()
            && Configuration::updateValue('MZC_SECURITY_ENABLED', 1)
            && Configuration::updateValue(
                'MZC_SECURITY_PATTERNS',
                json_encode([
                    '^__',                               // any email starting with double underscore
                    '^mail[a-z0-9]+@protonmail\\.com$',   // e.g. __mail0517187@protonmail.com
                    '@example\\.com$',                   // RFC example domain
                    '@test\\.com$',                      // generic test domain
                ])
            );
    }

    public function uninstall()
    {
        // NOTE: we intentionally do NOT drop ps_mzc_blocked on uninstall.
        // The blocked IP list is operational security data; dropping it on
        // reinstall would immediately re-allow all previously blocked users.
        return parent::uninstall()
            && Configuration::deleteByName('MZC_SECURITY_ENABLED')
            && Configuration::deleteByName('MZC_SECURITY_PATTERNS');
    }

    private function installDb()
    {
        $engine = defined('_MYSQL_ENGINE_') ? _MYSQL_ENGINE_ : 'InnoDB';

        return Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'mzc_blocked` (
                `id`         INT(11) NOT NULL AUTO_INCREMENT,
                `ip`         VARCHAR(45) NOT NULL,
                `email`      VARCHAR(255) NOT NULL DEFAULT \'\',
                `reason`     VARCHAR(255) NOT NULL DEFAULT \'\',
                `created_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uk_ip` (`ip`),
                KEY `idx_ip` (`ip`)
            ) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;'
        );
    }

    // -------------------------------------------------------------------------
    // Back-office configuration
    // -------------------------------------------------------------------------

    public function getContent()
    {
        $output = '';

        $this->context->controller->addCSS($this->_path . 'views/css/admin.css');

        // Handle unblock action
        $unblockId = (int) Tools::getValue('mzc_unblock_id');
        if ($unblockId > 0) {
            $output .= $this->handleUnblock($unblockId);
        }

        // Handle manual block
        if (Tools::isSubmit('submitMzcSecurityBlock')) {
            $output .= $this->handleManualBlock();
        }

        // Handle pattern save
        if (Tools::isSubmit('submitMzcSecurityPatterns')) {
            $output .= $this->handlePatternSave();
        }

        // Handle settings save
        if (Tools::isSubmit('submitMzcSecuritySettings')) {
            Configuration::updateValue('MZC_SECURITY_ENABLED', (int) Tools::getValue('MZC_SECURITY_ENABLED'));
            $output .= $this->displayConfirmation($this->l('Settings saved.'));
        }

        return $output
            . $this->renderSettingsForm()
            . $this->renderPatternsPanel()
            . $this->renderManualBlockPanel()
            . $this->renderBlockedTable();
    }

    private function handleUnblock($id)
    {
        $token = Tools::getValue('mzc_unblock_token');
        if ($token !== Tools::getAdminTokenLite('AdminModules')) {
            return $this->displayError($this->l('Invalid security token.'));
        }

        Db::getInstance()->execute(
            'DELETE FROM `' . _DB_PREFIX_ . 'mzc_blocked` WHERE `id` = ' . (int) $id
        );

        return $this->displayConfirmation($this->l('IP has been unblocked.'));
    }

    private function handleManualBlock()
    {
        $ip = trim(Tools::getValue('mzc_manual_ip'));

        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            return $this->displayError($this->l('Invalid IP address. Please enter a valid IPv4 or IPv6 address.'));
        }

        $normalizedIp = $this->normalizeIp($ip);
        $this->blockIp($normalizedIp, '', 'manual_admin');

        return $this->displayConfirmation(
            sprintf($this->l('IP %s has been blocked.'), htmlspecialchars($normalizedIp, ENT_QUOTES, 'UTF-8'))
        );
    }

    private function handlePatternSave()
    {
        $raw = Tools::getValue('mzc_patterns');
        $lines = array_filter(
            array_map('trim', explode("\n", $raw)),
            function ($l) { return $l !== ''; }
        );

        $valid = [];
        $invalid = [];
        foreach ($lines as $pattern) {
            // Test if pattern compiles (preg_match returns false on error)
            if (@preg_match('/' . $pattern . '/i', '') === false) {
                $invalid[] = $pattern;
            } else {
                $valid[] = $pattern;
            }
        }

        Configuration::updateValue('MZC_SECURITY_PATTERNS', json_encode(array_values($valid)));

        if ($invalid) {
            return $this->displayWarning(
                $this->l('Patterns saved. The following invalid patterns were skipped: ')
                . implode(', ', array_map(function ($p) {
                    return '<code>' . htmlspecialchars($p, ENT_QUOTES, 'UTF-8') . '</code>';
                }, $invalid))
            );
        }

        return $this->displayConfirmation($this->l('Email patterns saved successfully.'));
    }

    private function renderSettingsForm()
    {
        $fieldsForm = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Security Settings'),
                    'icon'  => 'icon-shield',
                ],
                'input' => [
                    [
                        'type'    => 'switch',
                        'label'   => $this->l('Enable Security Blocking'),
                        'name'    => 'MZC_SECURITY_ENABLED',
                        'is_bool' => true,
                        'desc'    => $this->l('When enabled, suspicious users are detected by email pattern and blocked by IP and browser fingerprint. Whitelisted IPs (PS_MAINTENANCE_IP) always bypass blocking.'),
                        'values'  => [
                            ['id' => 'active_on',  'value' => 1, 'label' => $this->l('Yes')],
                            ['id' => 'active_off', 'value' => 0, 'label' => $this->l('No')],
                        ],
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $helper->title = $this->displayName;
        $helper->submit_action = 'submitMzcSecuritySettings';

        $helper->fields_value['MZC_SECURITY_ENABLED'] = Configuration::get('MZC_SECURITY_ENABLED');

        return $helper->generateForm([$fieldsForm]);
    }

    private function renderPatternsPanel()
    {
        $patternsJson = Configuration::get('MZC_SECURITY_PATTERNS');
        $patterns = json_decode($patternsJson, true);
        if (!is_array($patterns)) {
            $patterns = [];
        }
        $patternsText = implode("\n", $patterns);

        $baseUrl = AdminController::$currentIndex
            . '&configure=' . $this->name
            . '&token=' . Tools::getAdminTokenLite('AdminModules');

        $this->context->smarty->assign([
            'mzc_patterns_text'  => $patternsText,
            'mzc_patterns_count' => count($patterns),
            'mzc_base_url'       => $baseUrl,
            'mzc_heading_patterns' => $this->l('Email Block Patterns'),
            'mzc_desc_patterns'    => $this->l('One regex pattern per line. A user whose email matches any pattern will have their IP blocked immediately. Patterns are case-insensitive.'),
            'mzc_label_save_patterns' => $this->l('Save Patterns'),
            'mzc_label_pattern_examples' => $this->l('Examples: ^__ blocks any email starting with double underscore. ^__[a-z0-9]+@protonmail\\.com$ targets the specific attack pattern. @example\\.com$ blocks the example.com domain.'),
        ]);

        return $this->display(__FILE__, 'views/templates/admin/patterns_form.tpl');
    }

    private function renderManualBlockPanel()
    {
        $baseUrl = AdminController::$currentIndex
            . '&configure=' . $this->name
            . '&token=' . Tools::getAdminTokenLite('AdminModules');

        $this->context->smarty->assign([
            'mzc_base_url'             => $baseUrl,
            'mzc_heading_manual_block' => $this->l('Manually Block an IP'),
            'mzc_desc_manual_block'    => $this->l('Enter an IPv4 or IPv6 address to block immediately. This is in addition to automatic detection.'),
            'mzc_label_ip_placeholder' => $this->l('e.g. 192.168.1.100 or 2001:db8::1'),
            'mzc_label_block_btn'      => $this->l('Block IP'),
        ]);

        return $this->display(__FILE__, 'views/templates/admin/manual_block_form.tpl');
    }

    private function renderBlockedTable()
    {
        $perPage = 20;
        $page = max(1, (int) Tools::getValue('mzc_page', 1));
        $totalCount = $this->getBlockedCount();
        $totalPages = max(1, (int) ceil($totalCount / $perPage));
        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        $entries = $this->getBlockedEntries($perPage, $offset);

        $baseUrl = AdminController::$currentIndex
            . '&configure=' . $this->name
            . '&token=' . Tools::getAdminTokenLite('AdminModules');

        $this->context->smarty->assign([
            'mzc_blocked_entries'  => $entries,
            'mzc_blocked_count'    => $totalCount,
            'mzc_admin_token'      => Tools::getAdminTokenLite('AdminModules'),
            'mzc_base_url'         => $baseUrl,
            'mzc_current_page'     => $page,
            'mzc_total_pages'      => $totalPages,
            'mzc_page_base_url'    => $baseUrl,
            'mzc_heading_blocked'  => $this->l('Blocked IPs'),
            'mzc_label_refresh'    => $this->l('Refresh'),
            'mzc_label_no_entries' => $this->l('No IPs are currently blocked.'),
            'mzc_th_id'            => $this->l('ID'),
            'mzc_th_ip'            => $this->l('IP'),
            'mzc_th_email'         => $this->l('Email'),
            'mzc_th_reason'        => $this->l('Reason'),
            'mzc_th_date'          => $this->l('Date'),
            'mzc_th_action'        => $this->l('Action'),
            'mzc_label_unblock'    => $this->l('Unblock'),
            'mzc_label_prev'       => $this->l('Previous'),
            'mzc_label_next'       => $this->l('Next'),
            'mzc_label_page'       => $this->l('Page'),
            'mzc_label_of'         => $this->l('of'),
        ]);

        return $this->display(__FILE__, 'views/templates/admin/blocked_table.tpl');
    }

    private function getBlockedEntries($limit, $offset)
    {
        $sql = 'SELECT `id`, `ip`, `email`, `reason`, `created_at`
                FROM `' . _DB_PREFIX_ . 'mzc_blocked`
                ORDER BY `created_at` DESC
                LIMIT ' . (int) $offset . ', ' . (int) $limit;

        $result = Db::getInstance()->executeS($sql);

        return $result ? $result : [];
    }

    private function getBlockedCount()
    {
        return (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'mzc_blocked`'
        );
    }

    // -------------------------------------------------------------------------
    // Hooks
    // -------------------------------------------------------------------------

    /**
     * Gate: runs on every front-office request.
     * Checks IP (DB) and cookie — if either is flagged, hangs the connection.
     */
    public function hookActionFrontControllerInitAfter($params)
    {
        if (!Configuration::get('MZC_SECURITY_ENABLED')) {
            return;
        }

        // Skip our own 'blocked' front controller to prevent an infinite loop
        if (
            $this->context->controller instanceof ModuleFrontController
            && $this->context->controller->module instanceof Module
            && $this->context->controller->module->name === $this->name
        ) {
            return;
        }

        if ($this->isWhitelisted()) {
            return;
        }

        // Cookie check (browser fingerprint)
        if (isset($_COOKIE['__mzc_b']) && $_COOKIE['__mzc_b'] === '1') {
            $this->showBlockedResponse();
        }

        // IP check (database)
        if ($this->isBlocked($this->normalizeIp(Tools::getRemoteAddr()))) {
            $this->showBlockedResponse();
        }
    }

    /**
     * Detect suspicious email on customer registration (before account is created).
     */
    public function hookActionSubmitAccountBefore($params)
    {
        if (!Configuration::get('MZC_SECURITY_ENABLED')) {
            return;
        }

        if (!isset($params['newCustomer']) || !is_object($params['newCustomer'])) {
            return;
        }

        $email = $params['newCustomer']->email;
        if ($this->matchesSuspiciousPattern($email)) {
            $this->blockIp($this->normalizeIp(Tools::getRemoteAddr()), $email, 'registration');
            $this->showBlockedResponse();
        }
    }

    /**
     * Detect suspicious email at checkout (before order is saved).
     */
    public function hookActionObjectOrderAddBefore($params)
    {
        if (!Configuration::get('MZC_SECURITY_ENABLED')) {
            return;
        }

        if (!isset($params['object']) || !($params['object'] instanceof Order)) {
            return;
        }

        $idCustomer = (int) $params['object']->id_customer;
        if ($idCustomer <= 0) {
            return;
        }

        $customer = new Customer($idCustomer);
        if (!Validate::isLoadedObject($customer)) {
            return;
        }

        if ($this->matchesSuspiciousPattern($customer->email)) {
            $this->blockIp($this->normalizeIp(Tools::getRemoteAddr()), $customer->email, 'checkout');
            $this->showBlockedResponse();
        }
    }

    /**
     * Detect suspicious email on successful login.
     */
    public function hookActionAuthentication($params)
    {
        if (!Configuration::get('MZC_SECURITY_ENABLED')) {
            return;
        }

        if (!isset($params['customer']) || !is_object($params['customer'])) {
            return;
        }

        $email = $params['customer']->email;
        if ($this->matchesSuspiciousPattern($email)) {
            $this->blockIp($this->normalizeIp(Tools::getRemoteAddr()), $email, 'login');
            $this->showBlockedResponse();
        }
    }

    /**
     * Inject localStorage checker on normal (non-blocked) pages.
     * If localStorage has the block flag set (from a previous session), redirect
     * to the blocked endpoint which will hang the connection and refresh the cookie.
     */
    public function hookDisplayBeforeBodyClosingTag($params)
    {
        if (!Configuration::get('MZC_SECURITY_ENABLED')) {
            return '';
        }

        if ($this->isWhitelisted()) {
            return '';
        }

        $blockedUrl = addslashes(
            $this->context->link->getModuleLink($this->name, 'blocked')
        );

        return '<script>
(function(){
    try {
        if (localStorage.getItem("__mzc_b") === "1") {
            window.location.replace("' . $blockedUrl . '");
        }
    } catch(e) {}
})();
</script>';
    }

    // -------------------------------------------------------------------------
    // Core helpers
    // -------------------------------------------------------------------------

    /**
     * Normalize an IP address to its canonical form so IPv6 variants
     * (e.g. ::1 vs 0:0:0:0:0:0:0:1) are stored and compared consistently.
     */
    private function normalizeIp($ip)
    {
        if (empty($ip)) {
            return $ip;
        }

        $packed = @inet_pton($ip);
        if ($packed === false) {
            return $ip; // not a valid IP — store as-is
        }

        return inet_ntop($packed);
    }

    /**
     * Check if the given email matches any configured suspicious pattern.
     */
    private function matchesSuspiciousPattern($email)
    {
        if (empty($email)) {
            return false;
        }

        $patternsJson = Configuration::get('MZC_SECURITY_PATTERNS');
        $patterns = json_decode($patternsJson, true);

        if (!is_array($patterns) || empty($patterns)) {
            return false;
        }

        foreach ($patterns as $pattern) {
            if (@preg_match('/' . $pattern . '/i', $email)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Record an IP in the blocked table.
     * ON DUPLICATE KEY: only fill empty email/reason fields (first detection wins,
     * but manual blocks with no email/reason can be enriched by later detections).
     */
    private function blockIp($ip, $email, $reason)
    {
        Db::getInstance()->execute(
            'INSERT INTO `' . _DB_PREFIX_ . 'mzc_blocked`
                (`ip`, `email`, `reason`, `created_at`)
             VALUES (
                 \'' . pSQL($ip) . '\',
                 \'' . pSQL($email) . '\',
                 \'' . pSQL($reason) . '\',
                 NOW()
             )
             ON DUPLICATE KEY UPDATE
                 `email`  = IF(`email` = \'\', VALUES(`email`), `email`),
                 `reason` = IF(`reason` = \'\', VALUES(`reason`), `reason`)'
        );
    }

    /**
     * Check if an IP is in the blocked list.
     */
    private function isBlocked($ip)
    {
        return (bool) Db::getInstance()->getValue(
            'SELECT `id` FROM `' . _DB_PREFIX_ . 'mzc_blocked`
             WHERE `ip` = \'' . pSQL($ip) . '\''
        );
    }

    /**
     * Check if the current visitor's IP is in the maintenance whitelist.
     * Supports CIDR notation via Symfony IpUtils; falls back to exact match.
     */
    private function isWhitelisted()
    {
        $maintenanceIps = Configuration::get('PS_MAINTENANCE_IP');
        if (empty($maintenanceIps)) {
            return false;
        }

        $ips = array_map('trim', explode(',', $maintenanceIps));
        $currentIp = Tools::getRemoteAddr();

        if (class_exists('Symfony\\Component\\HttpFoundation\\IpUtils')) {
            return \Symfony\Component\HttpFoundation\IpUtils::checkIp($currentIp, $ips);
        }

        return in_array($currentIp, $ips);
    }

    /**
     * Hang the connection silently — the browser shows an infinite loading spinner.
     *
     * Steps:
     *  1. Set the blocking cookie (1-year expiry).
     *  2. Declare a large Content-Length that will never be fulfilled.
     *  3. Flush headers to the browser.
     *  4. Send an inline <script> that sets localStorage — browsers execute
     *     inline scripts during streaming HTML parsing, so this fires even
     *     though the page never finishes loading.
     *  5. Sleep until PHP's max_execution_time terminates the process.
     *     The browser shows a loading spinner the entire time.
     */
    private function showBlockedResponse()
    {
        // Set blocking cookie — readable by JS (httponly=false) so the
        // localStorage setter in blocked.tpl can also refresh it via document.cookie
        setcookie('__mzc_b', '1', [
            'expires'  => time() + 365 * 24 * 3600,
            'path'     => '/',
            'secure'   => (bool) Tools::usingSecureMode(),
            'httponly' => false,
            'samesite' => 'Lax',
        ]);

        // Kill all output buffers so we can flush headers immediately
        while (ob_get_level()) {
            ob_end_clean();
        }

        // Disable on-the-fly gzip compression so Content-Length trick works
        if (function_exists('apache_setenv')) {
            @apache_setenv('no-gzip', '1');
        }
        @ini_set('zlib.output_compression', '0');

        // Send headers that look like a normal large page loading
        header('HTTP/1.1 200 OK');
        header('Content-Type: text/html; charset=utf-8');
        header('Content-Encoding: identity');    // no compression
        header('Content-Length: 10485760');       // 10 MB — never delivered
        header('X-Accel-Buffering: no');          // disable nginx proxy buffering
        header('Cache-Control: no-cache, no-store');

        // Flush headers to the client immediately
        flush();

        // Send a tiny inline script before sleeping.
        // Browsers parse and execute inline scripts during streaming (before
        // the document finishes loading), so localStorage gets set even though
        // the rest of the 10 MB never arrives.
        echo '<html><head>'
            . '<script>try{localStorage.setItem("__mzc_b","1");}catch(e){}</script>'
            . '</head><body>';
        flush();

        // Hang — PHP's max_execution_time will kill this process eventually.
        // Until then, the browser shows an infinite loading spinner.
        sleep(86400);
        exit;
    }
}
