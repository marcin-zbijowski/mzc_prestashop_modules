{*
 * MZC Security
 *
 * @author    Marcin Zbijowski Consulting
 * @copyright 2026 Marcin Zbijowski Consulting
 * @license   MIT
 *}
<div class="panel">
    <div class="panel-heading">
        <i class="icon-ban-circle"></i> {$mzc_heading_blocked|escape:'html':'UTF-8'}
        <span class="badge">{$mzc_blocked_count|intval}</span>
    </div>

    <div class="panel-body">
        <a href="{$mzc_base_url|escape:'html':'UTF-8'}" class="btn btn-default">
            <i class="icon-refresh"></i> {$mzc_label_refresh|escape:'html':'UTF-8'}
        </a>
    </div>

    {if $mzc_blocked_count > 0}
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>{$mzc_th_id|escape:'html':'UTF-8'}</th>
                            <th>{$mzc_th_ip|escape:'html':'UTF-8'}</th>
                            <th>{$mzc_th_email|escape:'html':'UTF-8'}</th>
                            <th>{$mzc_th_reason|escape:'html':'UTF-8'}</th>
                            <th>{$mzc_th_date|escape:'html':'UTF-8'}</th>
                            <th>{$mzc_th_action|escape:'html':'UTF-8'}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {foreach $mzc_blocked_entries as $entry}
                            <tr>
                                <td>{$entry.id|intval}</td>
                                <td><code>{$entry.ip|escape:'html':'UTF-8'}</code></td>
                                <td>{$entry.email|escape:'html':'UTF-8'}</td>
                                <td><span class="label label-warning">{$entry.reason|escape:'html':'UTF-8'}</span></td>
                                <td>{$entry.created_at|escape:'html':'UTF-8'}</td>
                                <td>
                                    <form method="post" action="{$mzc_base_url|escape:'html':'UTF-8'}" style="display:inline;">
                                        <input type="hidden" name="mzc_unblock_id" value="{$entry.id|intval}">
                                        <input type="hidden" name="mzc_unblock_token" value="{$mzc_admin_token|escape:'html':'UTF-8'}">
                                        <button type="submit"
                                                class="btn btn-danger btn-xs"
                                                onclick="return confirm('{l s='Are you sure you want to unblock this IP?' mod='mzcsecurity'}')">
                                            <i class="icon-unlock"></i> {$mzc_label_unblock|escape:'html':'UTF-8'}
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        {/foreach}
                    </tbody>
                </table>
            </div>

            {if $mzc_total_pages > 1}
                <div class="mzc-pagination" style="text-align:center; margin-top:15px;">
                    {if $mzc_current_page > 1}
                        <a href="{$mzc_page_base_url|escape:'html':'UTF-8'}&mzc_page={($mzc_current_page - 1)|intval}"
                           class="btn btn-default btn-sm">
                            &laquo; {$mzc_label_prev|escape:'html':'UTF-8'}
                        </a>
                    {/if}
                    <span style="margin: 0 10px;">
                        {$mzc_label_page|escape:'html':'UTF-8'} {$mzc_current_page|intval}
                        {$mzc_label_of|escape:'html':'UTF-8'} {$mzc_total_pages|intval}
                    </span>
                    {if $mzc_current_page < $mzc_total_pages}
                        <a href="{$mzc_page_base_url|escape:'html':'UTF-8'}&mzc_page={($mzc_current_page + 1)|intval}"
                           class="btn btn-default btn-sm">
                            {$mzc_label_next|escape:'html':'UTF-8'} &raquo;
                        </a>
                    {/if}
                </div>
            {/if}
        </div>
    {else}
        <div class="panel-body">
            <p class="text-muted">{$mzc_label_no_entries|escape:'html':'UTF-8'}</p>
        </div>
    {/if}
</div>
