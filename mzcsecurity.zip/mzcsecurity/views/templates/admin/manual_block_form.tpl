{*
 * MZC Security
 *
 * @author    Marcin Zbijowski Consulting
 * @copyright 2026 Marcin Zbijowski Consulting
 * @license   MIT
 *}
<div class="panel">
    <div class="panel-heading">
        <i class="icon-minus-circle"></i> {$mzc_heading_manual_block|escape:'html':'UTF-8'}
    </div>
    <div class="panel-body">
        <p class="help-block">{$mzc_desc_manual_block|escape:'html':'UTF-8'}</p>
        <form method="post" action="{$mzc_base_url|escape:'html':'UTF-8'}" class="form-inline">
            <div class="form-group">
                <input type="text"
                       name="mzc_manual_ip"
                       class="form-control mzc-ip-input"
                       placeholder="{$mzc_label_ip_placeholder|escape:'html':'UTF-8'}"
                       maxlength="45"
                       required>
            </div>
            &nbsp;
            <button type="submit" name="submitMzcSecurityBlock" class="btn btn-danger">
                <i class="icon-ban-circle"></i> {$mzc_label_block_btn|escape:'html':'UTF-8'}
            </button>
        </form>
    </div>
</div>
