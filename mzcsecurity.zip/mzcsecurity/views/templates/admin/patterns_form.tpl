{*
 * MZC Security
 *
 * @author    Marcin Zbijowski Consulting
 * @copyright 2026 Marcin Zbijowski Consulting
 * @license   MIT
 *}
<div class="panel">
    <div class="panel-heading">
        <i class="icon-filter"></i> {$mzc_heading_patterns|escape:'html':'UTF-8'}
        <span class="badge">{$mzc_patterns_count|intval}</span>
    </div>
    <div class="panel-body">
        <p class="help-block">{$mzc_desc_patterns|escape:'html':'UTF-8'}</p>
        <p class="help-block mzc-patterns-example">{$mzc_label_pattern_examples|escape:'html':'UTF-8'}</p>
        <form method="post" action="{$mzc_base_url|escape:'html':'UTF-8'}">
            <div class="form-group">
                <textarea name="mzc_patterns"
                          class="form-control mzc-patterns-textarea"
                          rows="8"
                          placeholder="^__&#10;@example\.com$&#10;@test\.com$"
                          spellcheck="false">{$mzc_patterns_text|escape:'html':'UTF-8'}</textarea>
            </div>
            <button type="submit" name="submitMzcSecurityPatterns" class="btn btn-primary">
                <i class="icon-save"></i> {$mzc_label_save_patterns|escape:'html':'UTF-8'}
            </button>
        </form>
    </div>
</div>
